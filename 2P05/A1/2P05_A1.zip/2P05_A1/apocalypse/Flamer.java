package apocalypse;
import java.util.LinkedList;

/**
 * This class defines the actions of a Flamer
 * 
 * @author Sawyer Fenwick | sf15zx | 6005011
 *
 */
public class Flamer extends Survivor {

	int num;
	
	/**
	 * Constructor 
	 * @param name name of hero
	 * @param list list of heroes
	 */
	public Flamer(String name, LinkedList<Survivor> list) {
		this.name = name;
	}//constructor
	
	/**
	 * Returns what happened
	 */
	@Override
	public String act() {
		num = 0;
		int size = Horde.horde.size();
		for(int j = 0; j < size; j++) {
			for(int i = 0; i < Horde.horde.size(); i++) {
				if(Horde.horde.get(i).getDistance() == 0) {
					Horde.horde.remove(i);
					Horde.replenish();
					num++;
				}
			}	
		}
		
		if(num == 0) {
			return "No zombies in range of " + name + "'s flamethrower";
		}
		else if(num == 1) {
			return name+" burnt " + num + " zombie to a crisp";
		}else {
			return name+" burnt " + num + " zombies to a crisp";
		}
	}//act

	/**
	 * Returns type of Survivor
	 */
	@Override
	public String getRole() {
		return "Flamer";
	}//getRole
}//Flamer