package apocalypse;
import java.util.LinkedList;

/**
 * This class defines the actions of a Plinker
 * 
 * @author Sawyer Fenwick | sf15zx | 6005011
 *
 */
public class Plinker extends Survivor {
	
	double random;
	int target;
	boolean killed;
	String zomb;
	
	/**
	 * Constructor 
	 * 
	 * @param name name of hero
	 * @param list list of heroes
	 */
	public Plinker(String name, LinkedList<Survivor> list) {
		this.name = name;
	}//constructor
	
	/**
	 * Returns what happened
	 */
	@Override
	public String act() {
		killed = false;
		for(int i = 0; i < 3; i++) {
			if(Horde.horde.isEmpty()) {
				break;
			}
			random = Math.floor(Math.random()*(Horde.horde.size()));
			target = (int)random;
			Horde.horde.get(target).deLimb(1);
			zomb = Horde.horde.get(target).getLabel();
			if(Horde.horde.get(target).getLimbs() == 0) {
				Horde.horde.remove(target); //kill zombie
				Horde.replenish(); //replenish horde
				killed = true;
			}
		}
		if(killed) {
			return name + " killed a " + zomb;
		}else {
			return name + " shot a " + zomb;
		}
	}//act

	/**
	 * Returns type of Survivor
	 */
	@Override
	public String getRole() {
		return "Plinker";
	}//getRole
}//Plinker