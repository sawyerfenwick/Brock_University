package apocalypse;

/**
 * Defines a Deadite zombie
 * 
 * @author Sawyer Fenwick | sf15zx | 6005011
 *
 */
public class Deadite implements Undead {
	
	private int hunger = 1;
	private int distance = 4;
	private int limbs = 4;
	
	/**
	 * Returns distance of a Deadite 0-4
	 */
	public int getDistance() {
		return distance;
	}//getDistance
	
	/**
	 * Injures a survivor, returns the name of the survivor
	 */
	public String chomp(Survivor victim) {
		if(getHungry()) {
			hunger = 0;
			victim.injure(1);
			return "Deadite chomped " + victim;
		}
		hunger++;
		return "Deadite: *braaaainnnsss*";
	}//chomp
	
	/**
	 * Advances Deadite one space so long as it is not already
	 * at the front of the line
	 */
	public void move() {
		if(distance != 0) {
			distance--;
		}
	}//move
	
	/**
	 * Returns number of spaces Deadite moved
	 */
	public String advance() {
		if(distance == 1) {
			move();
			return "Deadite advanced one space";
		}
		move();
		if(distance == 0) {
			return "Deadite stays at the front line";
		}else {
			return "Deadite advanced one space";
		}	 
	}//advance
	
	/**
	 * Returns health of the Deadite
	 */
	public int getLimbs() {
		return limbs; 
	}//getLimbs
	
	/**
	 * Deals damage to a Deadite
	 * 
	 * @param force damage dealt
	 */
	public void deLimb(int force) {
		limbs -= force;
	}//deLimb
	
	/**
	 * Returns hugner status of Deadite
	 */
	public boolean getHungry() {
		if(hunger == 1) {
			return true;
		}
		else {
			return false;
		}
	}//getHungry
	
	/**
	 * Returns D for Deadite
	 */
	public String getLabel() {
		return "D";
	}//getLabel
	
	/**
	 * Returns a single character D and the appropriate 
	 * padding for the distance of the Deadite  
	 * 
	 * @param u the zombie 
	 * @return a single character D
	 */
	static public String render(Undead u) {
		String padding="     ";
		return u==null?
				"    "
				:
					padding.substring(0,4-u.getDistance())+u.toString()+padding.substring(0,u.getDistance());
	}//render
}//Deadite