package apocalypse;

/**
 * Defines a Trioxin zombie
 * 
 * @author Sawyer Fenwick | sf15zx | 6005011
 *
 */
public class Trioxin implements Undead {
	
	private int hunger = 1;
	private int distance = 4;
	private int limbs = 4;
	
	/**
	 * Returns distance of Trioxin 0-4
	 */
	public int getDistance() {
		return distance; 
	}//getDistance
	
	/**
	 * Injures a survivor, returns the name of the survivor
	 */
	public String chomp(Survivor victim) {
		if(getHungry()) {
			hunger = 0;
			victim.injure(2);
			return "Trioxin chomped " + victim.name;
		}else {
			hunger++;
			return "Trioxin: " + speak();
		}
	}//chomp
	
	/**
	 * Advances Trioxin two spaces so long as it is not already
	 * at the front of the line
	 */
	public void move() {
		if(distance != 0) {
			distance -= 2;
		}
	}//move
	
	/**
	 * Returns number of spaces Trioxin moved
	 */
	public String advance() {
		if(distance == 2) {
			move();
			return "Trioxin advanced two spaces";
		}
		move();
		if(distance == 0) {
			return "Trioxin stays at the front line";
		}else {
			return "Trioxin advanced two spaces";
		}
	}//advance
	
	/**
	 * Returns health of the Deadite
	 */
	public int getLimbs() {
		return limbs; 
	}//getLimbs
	
	/**
	 * Deals damage to a Deadite
	 * 
	 * @param force damage dealt
	 */
	public void deLimb(int force) {
		limbs -= force;
	}//deLimb
	
	/**
	 * Returns hugner status of Trioxin
	 */
	public boolean getHungry() {
		if(hunger == 1) {
			return true;
		}
		else {
			return false;
		}
	}//getHungry
	
	/**
	 * Custom speak string for a Trioxin
	 */
	public String speak() {
		return getHungry()?"Send more Paramedics!!!":"*groans*";
	}//speak
	
	/**
	 * Returns T for Trioxin
	 */
	public String getLabel() {
		return "T";
	}//getLabel
	
	/**
	 * Returns a single character T and the appropriate 
	 * padding for the distance of the Trioxin  
	 * 
	 * @param u the zombie 
	 * @return a single character T
	 */
	static public String render(Undead u) {
		String padding="     ";
					 //"43210"
		return u==null?
				"    "
				:
					padding.substring(0,4-u.getDistance())+u.getLabel()+padding.substring(0,u.getDistance());
	}//render
}//Trioxin