package apocalypse;
import java.util.ArrayList;

/**
 * Horde class, I modified it slightly
 * 
 * @author Sawyer Fenwick | sf15zx | 6005011 
 * 
 * @see CHUD
 * @see Deadite
 * @see Trioxin
 *
 */
public class Horde {
	private static int remaining;
	private static int breadth;
	static ArrayList<Undead> horde;
	
	/**
	 * Returns number of zombies left in the HORDE
	 * 
	 * @return remaining zombies left
	 */
	public static int getRemaining() {
		return remaining;
	}//getRemaining
	
	/**
	 * For initializing the horde. 
	 * 
	 * @param remaining How many Undeadies can be summoned
	 * @param breadth How many can be on the field at any given time
	 */
	static void populate(int remaining, int breadth) {
		Horde.remaining = remaining;
		Horde.breadth = breadth;
		Horde.horde = new ArrayList<>(remaining);
		Horde.replenish();
	}
	
	/**
	 * Convenience operator added to easily replenish the horde after
	 * a chompy-boi is eliminated
	 * 
	 * @param pos Position of recently receased
	 */
	public static void replenish() {
		if(Horde.remaining!=0) {
			int x = breadth - Horde.horde.size();
			for(int i = 0; i < x; i++) {
				double r = Math.random();
				if(r<0.25) {
					Horde.horde.add(new CHUD());
				}
				else if(r<0.75) {
					Horde.horde.add(new Deadite());
				}
				else {
					Horde.horde.add(new Trioxin());
				}
				Horde.remaining--;
			}
		}
	}
}
