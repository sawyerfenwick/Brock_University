package apocalypse;
import java.util.LinkedList;

/**
 * This class defines the actions of a Sniper
 * 
 * @author Sawyer Fenwick | sf15zx | 6005011
 *
 */
public class Sniper extends Survivor {
	
	double random;
	int target;
	String zomb;
	
	/**
	 * Constructor 
	 * 
	 * @param name name of hero
	 * @param list list of heroes
	 */
	public Sniper(String name, LinkedList<Survivor> list) {
		this.name = name;
	}//constructor
	
	/**
	 * Returns what happened
	 */
	@Override
	public String act() {
		random = Math.floor(Math.random()*(Horde.horde.size()));
		target = (int)random;
		Undead u = Horde.horde.get(target);
		zomb = Horde.horde.get(target).getLabel();
		Horde.horde.remove(u); //kill zombie
		Horde.replenish(); //replenish horde
		return name + " blew the face off a " + zomb;
	}//act

	/**
	 * Returns type of Survivor
	 */
	@Override
	public String getRole() {
		return "Sniper";
	}//getRole
}//Sniper