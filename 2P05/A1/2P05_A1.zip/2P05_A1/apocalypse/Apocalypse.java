package apocalypse;
import java.util.Scanner;
import java.util.LinkedList;

/**
 * Main class for the package "Apocalypse" 
 * 
 * @author Sawyer Fenwick | sf15zx | 6005011
 *
 */
public class Apocalypse {
	
	LinkedList<Survivor> heroes = new LinkedList<>(); //list of heroes
	Scanner sc = new Scanner(System.in); //scanner for user input
	boolean gameover = false; //checking if user quit
	
	/**
	 * Constructor
	 */
	public Apocalypse() {
		System.out.println("===Save Our City===");
		menu();
	}//constructor
	
	/**
	 * Prints the menu, prompts user, waits for input
	 */
	private void menu() {
		System.out.println("1.Start Game");
		System.out.println("0.Quit");
		int input = -1;
		while(input != 0 && input != 1) {
			try {
				input = sc.nextInt();
			}catch(Exception e) {
				System.out.println("Incorrect Input");
				sc.next();
			}
			if(input == 1) {
				System.out.println("Build Your Team:");
				buildTeam();
			}
			if(input != 0 && input != 1) {
				System.out.println("Incorrect Input");
			}
		}
	}//menu
	
	/**
	 * Builds the team of heroes off user input
	 */
	private void buildTeam() {
		String name;
		int input;
		System.out.println("===Heroes===");
		for(int i = 0; i < 4; i++) {
			System.out.println("Hero " + (i+1));
			System.out.println("1.Plinker: Deals 3 Damage");
			System.out.println("2.Flamer: Insta Kills ALL Zombies at Position 0");
			System.out.println("3.Sniper: Insta Kills One Zombie");
			System.out.println("4.Medic: Heals The Party, Cannot Deal Damage.");
			input = -1;
			while(input !=1 && input !=2 && input !=3 && input !=4) {
				try {
					input = sc.nextInt();
				}catch (Exception e) {
					System.out.println("Incorrect Input");
					sc.next();
				}
				if(input !=1 && input !=2 && input !=3 && input !=4) {
					System.out.println("Incorrect Input");
				}
			}
			switch(input) {
			case 1:
				System.out.println("Hero " + (i+1) + ": Plinker");
				System.out.println("Name your Plinker: ");
				name = sc.next();
				heroes.add(new Plinker(name,heroes));
				break;
			case 2:
				System.out.println("Hero " + (i+1) + ": Flamer");
				System.out.println("Name Your Flamer: ");
				name = sc.next();
				heroes.add(new Flamer(name,heroes));
				break;
			case 3:
				System.out.println("Hero " + (i+1) + ": Sniper");
				System.out.println("Name Your Sniper: ");
				name = sc.next();
				heroes.add(new Sniper(name,heroes));
				break;
			case 4:
				System.out.println("Hero " + (i+1) + ": Medic");
				System.out.println("Name Your Medic: ");
				name = sc.next();
				heroes.add(new Medic(name,heroes));
				break;
			default:
				System.out.println("Incorrect Input");
			}
		}
		System.out.println("===Zombies===");
		System.out.println("Create the HORDE:");
		buildZombies();
	}//buildTeam
	
	/**
	 * Prompts user for size of horde, breadth of horde, and number of waves
	 */
	private void buildZombies() {
		int size = 0;
		int breadth = 0;
		int waves = 0;
		
		System.out.println("How Many Zombies Will Be In The HORDE?");
		while(size == 0) {
			try {
				size = sc.nextInt();
			}catch (Exception e) {
				sc.next();
			}
			if(size<=0) {
				System.out.println("Incorrect Input");
			}
		}
		System.out.println("How Many Zombies On The Field At Once:");
		while(breadth == 0) {
			try {
				breadth = sc.nextInt();
			}catch (Exception e) {
				sc.next();
			}
			if(breadth<=0) {
				System.out.println("Incorrect Input");
			}
		}
		System.out.println("How Many Waves Will You Face?");
		while(waves == 0) {
			try {
				waves = sc.nextInt();
			}catch (Exception e) {
				sc.next();
			}
			if(waves<=0) {
				System.out.println("Incorrect Input");
			}
		}
		play(size,breadth,waves);
	}//buildZombies
	
	/**
	 * Begins the game
	 * 
	 * @param size number of zombies total
	 * @param breadth number of zombies in play 
	 * @param waves number of rounds 
	 */
	private void play(int size, int breadth, int waves) {
		for(int i = 0; i < waves; i++) {
			System.out.println("===WAVE " + (i+1) + "===");
			Horde.populate(size, breadth);
			drawField();
			while(!Horde.horde.isEmpty()) {
				iterate();
				if(gameover) {
					break;
				}
				if(heroes.isEmpty()) {
					System.out.println("You Lose.");
					System.out.println("You Have Joined The Horde.");
				}
			}
			if(gameover) {
				break;
			}
			System.out.println("===WAVE COMPLETE===");
			if(Horde.horde.isEmpty()) {
				if(i == waves-1) {
					System.out.println("You Win!");
					if(waves == 1) {
						System.out.println("You Have Defeated The Horde.");
					}else {
						System.out.println("You Have Deafeated All " + waves + " Waves Of The Horde.");
					}
				}
			}
		}
	}//play

	/**
	 * 1.Draw Field
	 * 2.Zombies Advance
	 * 3.Zombies Attack
	 * 4.Hero in front Attacks
	 * 5.Hero in front moves to back
	 * 6.Draw Field
	 */
	private void iterate() {
		int input = -1;
		
		drawField();
		
		for(Undead u:Horde.horde) {
			System.out.println(u.advance());
			System.out.println(u.speak());
			if(u.getDistance() == 0) {
				if(u.getHungry()) {
					System.out.println(u.chomp(heroes.getFirst()));
					if(heroes.getFirst().getHP() <= 0) {
						System.out.println(heroes.getFirst().name + "WAS EATEN ALIVE");
						heroes.removeFirst();
					}
				}
			}
		}
		drawField();
		System.out.println("You are in control of: " + heroes.getFirst().name);
		while(input != 0 && input != 1 && input != 2) {
			System.out.println("1.Act		2.Star Over		0.Quit");
			try {
				input = sc.nextInt();
			}catch (Exception e) {
				System.out.println("Incorrect Input");
			}
		}
		switch(input) {
		case 1:
			System.out.println(heroes.getFirst().act());
			break;
		case 2:
			System.out.println("Game Over.");
			System.out.println("Starting Over... ... ...");
			heroes.clear();
			menu();
			break;
		case 0:
			System.out.println("Game Over.");
			gameover = true;
			break;
		}
		if(heroes.size()>0) {
			Survivor s = heroes.removeFirst();
			heroes.addLast(s);
		}
	}//iterate
	
	/**
	 * Draws the field of zombies and heroes
	 */
	private void drawField() {
		for(int i = 0; i < Horde.horde.size(); i++) {
			System.out.print(Undead.render(Horde.horde.get(i)));
			System.out.print("|");
			if(i==Horde.horde.size()/2) {
				for(Survivor hero:heroes) System.out.print(hero);
			}
			System.out.println();
		}
	}//drawField
	
	public static void main (String args[]) {
		new Apocalypse();
	}//main
}//Apocalypse
