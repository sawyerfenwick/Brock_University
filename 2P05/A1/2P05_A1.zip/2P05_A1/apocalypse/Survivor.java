package apocalypse;

/**
 * Abstract class representing the basic functionality of a Survivor
 * 
 * @see Plinker
 * @see Medic
 * @see Flamer
 * @see Sniper
 */
public abstract class Survivor {
	final static int maxHP = 5;
	final static String victory = "YAY";
	private int hitpoints = Survivor.maxHP;
	String name;
	
	/**
	 * @return What happened
	 */
	abstract public String act();
	
	/**
	 * @return health of Survivor
	 */
	public int getHP() {
		return hitpoints;
	}//getHP
	
	/**
	 * Reduces the HP of the Survivor injured
	 * @param amt delta value
	 */
	public void injure(int amt) {
		this.hitpoints-=amt;
		this.hitpoints=this.hitpoints<0?0:this.hitpoints>Survivor.maxHP?Survivor.maxHP:this.hitpoints;
	}//injure
	
	/**
	 * Returns "Sniper", "Medic", "Flamer" or "Plinker"
	 * @return Role
	 */
	abstract public String getRole();
	
	/**
	 * 
	 * @return name of Survivor
	 */
	public String getName() {
		return name;
	}//getName
	
	/**
	 * Overridden String representation of a Survivor
	 */
	public String toString() {
		return '['+getName()+':'+getRole()+'|'+getHP()+']';
	}//toString
}//Survivor