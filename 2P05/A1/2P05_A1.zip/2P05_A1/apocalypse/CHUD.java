package apocalypse;

/**
 * Defines a CHUD zombie
 * 
 * @author Sawyer Fenwick | sf15zx | 6005011
 *
 */
public class CHUD implements Undead {
	
	private int distance = 4;
	private int limbs = 4;
	
	/**
	 * Returns distance of CHUD 0-4
	 */
	public int getDistance() {
		return distance;
	}//getDistance
	
	/**
	 * Injures a survivor, returns the name of the survivor
	 */
	public String chomp(Survivor victim) {
		victim.injure(1);
		return "CHUD chomped " + victim; 
	}//chomp
	
	/**
	 * Advances CHUD one space so long as it is not already
	 * at the front of the line
	 */
	public void move() {
		if(distance !=0) {
			distance--;
		}
	}//move
	
	/**
	 * Returns number of spaces CHUD moved
	 */
	public String advance() {
		if(distance == 1) {
			move();
			return "CHUD advanced one space";
		}
		move();
		if(distance == 0) {
			return "CHUD stays at the front line";
		}else {
			return "CHUD advanced one space"; 
		}
	}//advance
	
	/**
	 * Returns health of the CHUD
	 */
	public int getLimbs() {
		return limbs; 
	}//getLimbs
	
	/**
	 * Deals damage to a CHUD
	 * 
	 * @param force damage dealt
	 */
	public void deLimb(int force) {
		limbs -= force;
	}//deLimb
	
	/**
	 * Returns hugner status of CHUD
	 */
	public boolean getHungry() {
		return true;
	}//getHungry
	
	/**
	 * Returns C for CHUD
	 */
	public String getLabel() {
		return "C";
	}//getLabel
	
	/**
	 * Returns a single character C and the appropriate 
	 * padding for the distance of the CHUD  
	 * 
	 * @param u the zombie 
	 * @return a single character C
	 */
	static public String render(Undead u) {
		String padding="     ";
		return u==null?
				"    "
				:
					padding.substring(0,4-u.getDistance())+u.toString()+padding.substring(0,u.getDistance());
	}//render
}//CHUD
