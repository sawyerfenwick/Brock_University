package apocalypse;
import java.util.LinkedList;

/**
 * This class defines the actions of a Medic 
 * 
 * @author Sawyer Fenwick | sf15zx | 6005011
 *
 */
public class Medic extends Survivor {
	LinkedList<Survivor> list;
	/**
	 * Constructor 
	 * 
	 * @param name name of hero
	 * @param list list of heroes
	 */
	public Medic(String name, LinkedList<Survivor> l) {
		this.name = name;
		list = l;
	}//constructor
	
	/**
	 * Heals the party. Uses injure with negative values
	 * 
	 * @param heroes list of heroes
	 */
	public void heal(LinkedList<Survivor> list) {
		for(int i = 0; i < list.size(); i++) {
			switch(list.get(i).getHP()) {
			case 4:
				list.get(i).injure(-1);
			case 3:
				list.get(i).injure(-2);
			case 2:
				list.get(i).injure(-3);
			case 1:
				list.get(i).injure(-4);
			}
		}
	}//heal
	
	/**
	 * Returns what happened
	 */
	@Override
	public String act() {
		heal(list);
		return this.name + " healed the party";
	}//act

	/**
	 * Returns type of Survivor 
	 */
	@Override
	public String getRole() {
		return "Medic";
	}//getRole
}//Medic