package Assign_4;


/** This class references the node being used. 
  * 
  * @author S. Fenwick
  *
  * @version 1.0 (March. 2017)                                                     */

class Node{
  
  Product item; //product to be sold
  Node next; //next node
  
  Node(Product p, Node n){
    
    item = p;
    next = n;
    
  } //constructor
  
} //Node