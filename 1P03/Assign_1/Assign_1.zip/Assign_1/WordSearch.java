package Assign_1;

import BasicIO.*;
/** This class loads a .txt file containing the dimensions of an array (int), the contents of the array (char), and 
  * the words that need to be found (String). It then displays the wordsearch on an ASCIIDisplayer, and it displays 
  * the location of each word found, the (x,y) co-ordinate where it was found, and the direction (U,L,R,D,UL,UR,DL,DR).
  *
  * @author Sawyer Fenwick(st# 6005011)
  *
  * @version 1.0 February 2 2017
  */
public class WordSearch{
  
  /* Instance Variables */
  private ASCIIDisplayer display;
  private ASCIIDataFile pData;
  
  private char[] [] puzzle;
  
  /*this constructor calls the loadPuzzle method*/
  public WordSearch(){
    
    display = new ASCIIDisplayer();
    pData = new ASCIIDataFile();
    
    loadPuzzle();
    
    pData.close();
    display.close();
    
  } //constructor
  
  /*this method loads the puzzle from a .txt file, creates the search array, calls the displayPuzzle() method, and 
   * iterates through each word sending it to the check() method to find where it is on the puzzle.*/
  private void loadPuzzle(){
    int x = pData.readInt();
    int y = pData.readInt();
    
    puzzle = new char[x][y];
    
    for(int i = 0; i < puzzle.length; i ++){
      for(int j = 0; j < puzzle[i].length; j ++){
        
        puzzle[i][j] = pData.readChar();
       
      }
    }
    
    displayPuzzle();
    
    for(;;){
      
      String word = pData.readString();
      if(pData.isEOF()) break;
      check(word);
    }
    
  } //loadPuzzle
  
  /*this method displays the puzzle*/
  private void displayPuzzle(){
    
    for(int i = 0; i < puzzle.length; i ++){
      for(int j = 0; j < puzzle[i].length; j ++){
        
        display.writeChar(puzzle[i][j]);
        
      }
      display.newLine();
    }
    display.newLine();
    
  }
  /*this method recieves a word from the loadPuzzle() method, converts it to a char array and takes the first letter. 
   * it then iterates through each co-ordinate of the puzzle and compares the letter it is currently at with the first 
   * letter of the char array. if they are a match it will check the 8 directions around the letter, looking for a 
   * complete word match. it then writes to the displayer where it has found the word.*/
  private void check(String word){

    char[] wordA = word.toCharArray();
    
    for(int x = 0; x < puzzle.length; x ++){
      for(int y = 0; y < puzzle[x].length; y ++){
     
        char firstLetter = wordA[0];
        char currentLetter = puzzle[x][y]; 
        if(firstLetter == currentLetter){
          
          if (checkRight(x, y, word)){
            display.writeString(word + " " + " found (right) at (" + x + " , " + y + ")" );
            display.newLine();
          } else if (checkLeft(x, y, word)){
            display.writeString(word + " " + "found (left) at (" + x + " , " + y + ")" );
            display.newLine();
          } else if (checkUp(x, y, word)){
            display.writeString(word + " " + "found (up) at (" + x + " , " + y + ")" );
            display.newLine();
          } else if (checkDown(x, y, word)){
            display.writeString(word + " " + "found (down) at (" + x + " , " + y + ")" );
            display.newLine();
          } else if (checkDownRight(x, y, word)){
            display.writeString(word + " " + "found (down right) at (" + x + " , " + y + ")" );
            display.newLine();
          } else if (checkDownLeft(x, y, word)){
            display.writeString(word + " " + "found (down left) at (" + x + " , " + y + ")" );
            display.newLine();
          } else if (checkUpRight(x, y, word)){
            display.writeString(word + " " + "found (up right) at (" + x + " , " + y + ")" );
            display.newLine();
          } else if (checkUpLeft(x, y, word)){
            display.writeString(word + " " + "found (up left) at (" + x + " , " + y + ")" );
            display.newLine();
          } 
        }
      }
    }
  }
  /*this method searches a row to the right, checking if the two letters at the co-ordinates passed
   * (one from the word being searched, and the other from the current row being searched) are the same. If they are 
   * then the word has been found. If they are not then it breaks and checks returns false to the check() method which 
   * will prompt a new search. */
  private boolean checkRight(int x, int y, String word){
    //variables
    boolean found = false;
    char[] wordA = word.toCharArray();
    
    if(wordA.length + y <= puzzle.length){ 
     
      for(int k = 0; k < wordA.length; k ++){
      
        char letter = wordA[k];
        char currentLetter = puzzle[x][y + k];
        
        if(letter != currentLetter){
          found = false;
          break;
        }
        found = true;
      }
      
    }
    return found;
  }
  /*this method searches a row to the left, checking if the two letters at the co-ordinates passed
   * (one from the word being searched, and the other from the current row being searched) are the same. If they are 
   * then the word has been found. If they are not then it breaks and checks returns false to the check() method which 
   * will prompt a new search. */
  private boolean checkLeft(int x, int y, String word){
    //variables
    boolean found = false;
    char[] wordA = word.toCharArray();
    
    if(y + 1 - wordA.length >= 0){
      
      for(int k = 1; k < wordA.length; k ++){
        
        char letter = wordA[k];
        char currentLetter = puzzle[x][y - k];
        
        if(letter != currentLetter){
          found = false;
          break;
        }
        found = true;
      }
    }
    return found;
  }
  /*this method searches up a column, checking if the two letters at the co-ordinates passed
   * (one from the word being searched, and the other from the current row being searched) are the same. If they are 
   * then the word has been found. If they are not then it breaks and checks returns false to the check() method which 
   * will prompt a new search. */
  private boolean checkUp(int x, int y, String word){
    //variables
    boolean found = false;
    char[] wordA = word.toCharArray();
    
    if(x + 1 - wordA.length >= 0){
      
      for(int k = 0; k < wordA.length; k ++){
        
        char letter = wordA[k];
        char currentLetter = puzzle[x - k][y];
        
        if(letter != currentLetter){
          found = false;
          break;
        }
        found = true;
      }
    }
    return found;
  }
  /*this method searches down a column, checking if the two letters at the co-ordinates passed
   * (one from the word being searched, and the other from the current row being searched) are the same. If they are 
   * then the word has been found. If they are not then it breaks and checks returns false to the check() method which 
   * will prompt a new search. */
  private boolean checkDown(int x, int y, String word){
    //variables
    boolean found = false;
    char[] wordA = word.toCharArray();
    
    if(x + wordA.length <= puzzle.length){
      
      for(int k = 0; k < wordA.length; k ++){
        
        char letter = wordA[k];
        char currentLetter = puzzle[x + k][y];
        
        if(letter != currentLetter){
          found = false;
          break;
        }
        found = true;
      }
    } 
    return found;
  }
  /*this method searches diagonally down and to the right, combing the checkDown() and checkRight() methods, checking 
   * if the two letters at the co-ordinates passed (one from the word being searched, and the other from the current 
   * row being searched) are the same. If they are then the word has been found. If they are not then it breaks and 
   * checks returns false to the check() method which will prompt a new search. */
  private boolean checkDownRight(int x, int y, String word){
    //variables
    boolean found = false;
    char[] wordA = word.toCharArray();
    
    if(wordA.length + y <= puzzle.length -1){
      if (x + wordA.length <= puzzle.length){ 
        
        for(int k = 0; k < wordA.length; k++){
          
          char letter = wordA[k];
          char currentLetter = puzzle[x + k][y + k];
          
          if(letter != currentLetter){
            found = false;
            break;
          }
          found = true;
        }
      }
    }
    return found;
  }  
  /*this method searches diagonally down and to the left, combing the checkDown() and checkLeft() methods, checking 
   * if the two letters at the co-ordinates passed (one from the word being searched, and the other from the current 
   * row being searched) are the same. If they are then the word has been found. If they are not then it breaks and 
   * checks returns false to the check() method which will prompt a new search. */
  private boolean checkDownLeft(int x, int y, String word){
    boolean found = false;
    char[] wordA = word.toCharArray();
    
    if (y + 1 - wordA.length >= 0){ 
      if(x + wordA.length<= puzzle.length){
        
        for(int k = 0; k < wordA.length; k ++){
         
          char letter = wordA[k];
          char currentLetter = puzzle[x + k][y - k];
          
          if( letter != currentLetter){
            found = false;
            break;
          }
          found = true;
        }
      }
    }
    return found;
  }
  /*this method searches diagonally up and to the right, combing the checkUp() and checkRight() methods, checking 
   * if the two letters at the co-ordinates passed (one from the word being searched, and the other from the current 
   * row being searched) are the same. If they are then the word has been found. If they are not then it breaks and 
   * checks returns false to the check() method which will prompt a new search. */
  private boolean checkUpRight(int x, int y, String word){
    //variables
    boolean found = false;
    char[] wordA = word.toCharArray();
    
    if(wordA.length + y <= puzzle.length){
      if (x-wordA.length >= 0){ 
        
        for(int k = 0; k < wordA.length; k++){
          
          char letter = wordA[k];
          char currentLetter = puzzle[x - k][y + k];
          
          if(letter != currentLetter){
            found = false;
            break;
          }
          found = true;
        }
      }
    }
    return found;
  }
  /*this method searches diagonally up and to the left, combing the checkUp() and checkLeft() methods, checking 
   * if the two letters at the co-ordinates passed (one from the word being searched, and the other from the current 
   * row being searched) are the same. If they are then the word has been found. If they are not then it breaks and 
   * checks returns false to the check() method which will prompt a new search. */
  private boolean checkUpLeft(int x, int y, String word){
    //variables
    boolean found = false;
    char[] wordA = word.toCharArray();
    
    if (x - wordA.length >= 0){ 
      if(y + 1 - wordA.length >= 0){
        
        for(int k = 0; k < wordA.length; k ++){
          
          char letter = wordA[k];
          char currentLetter = puzzle[x-k][y-k];
          
          if( letter !=currentLetter){
            found = false;
            break;
          }
          found = true;
        }
      }
    }
    return found;
  }
  
  public static void main (String args[] ) {WordSearch wS = new WordSearch();};
  
} //WordSearch